<?php
error_reporting(1);

$con = mysqli_connect("127.0.0.1:3306","u442507923_udaq","1q2w3e","u442507923_udaq") or die(mysql_error());



?>
