<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>User Signup</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
include("header.php");
extract($_POST);
$idex = $_REQUEST['idex'];
require("../database.php");

$query0="SELECT * FROM `reactivos` WHERE 1";

$rs0=mysqli_query($con,$query0)or die("no se registro error error");
$idr = mysqli_num_rows($rs0) + 1;

$query2="SELECT * FROM `incisos` WHERE 1";
$rs2=mysqli_query($con,$query2)or die("no se registro error error2");
$ida = mysqli_num_rows($rs2) + 1;
$idb = mysqli_num_rows($rs2) + 2;
$idc = mysqli_num_rows($rs2) ;
echo "idr: $idr";
echo "</br>";
echo "preg: $preg";
echo "</br>";
echo "ida: $ida";
echo "</br>";
echo "idb: $idb";
echo "</br>";
echo "idc: $idc";
echo "</br>";
echo "idex: $idex";
echo "</br>";
$query="insert into reactivos(IDReactivo,Pregunta,IDCorrecta,IDExamen)values ('$idr','$preg','$idc','$idex')";

$rs=mysqli_query($con,$query)or die("no se registro error error");

echo "$ida";
$query3="insert into incisos(IDInciso,Inciso,IDReactivo)values ('$ida','$a','$idr')";
$query4="insert into incisos(IDInciso,Inciso,IDReactivo)values ('$idb','$b','$idr')";
$rs3=mysqli_query($con,$query3)or die("no se registro error error3");
$rs4=mysqli_query($con,$query4)or die("no se registro error error4");

//-------------------------------------------------------------------------------
$query0="SELECT * FROM `reactivos`";

$rs0=mysqli_query($con,$query0)or die("no se registro error error");
$idr = mysqli_num_rows($rs0) + 1;

$query2="SELECT * FROM `incisos`";
$rs2=mysqli_query($con,$query2)or die("no se registro error error2");
$ida = mysqli_num_rows($rs2) + 1;
$idb = mysqli_num_rows($rs2) + 2;
$idc = mysqli_num_rows($rs2) + $n2;
echo "idr: $idr";
$query="insert into reactivos(IDReactivo,Pregunta,IDCorrecta,IDExamen)values ('$idr','$preg2','$idc','$idex')";

$rs=mysqli_query($con,$query)or die("no se registro error error");

echo "$ida";
$query3="insert into incisos(IDInciso,Inciso,IDReactivo)values ('$ida','$a2','$idr')";
$query4="insert into incisos(IDInciso,Inciso,IDReactivo)values ('$idb','$b2','$idr')";
$rs3=mysqli_query($con,$query3)or die("no se registro error error3");
$rs4=mysqli_query($con,$query4)or die("no se registro error error4");


echo "<p align=center>Test <b>\"$testname\"</b> Added Successfully.</p>";

unset($_POST);

?>
</body>
</html>

