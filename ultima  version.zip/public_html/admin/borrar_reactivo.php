<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>User Signup</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php

extract($_POST);
include("../database.php");
	$idex = $_REQUEST['idex'];
	$idr = $_REQUEST['idr'];
      

 
  
   
 
$query="DELETE FROM reactivos WHERE IDReactivo = '$idr' and IDExamen = '$idex'";
$rs=mysqli_query($con,$query)or die("Could Not Perform the Query");
echo "<br><br><br><div class=head1>Usuario borrado correctamente.</div>";



header("location: gestion_reactivos.php?id=".$idex); 


?>
</body>
</html>

